// ---------------------------------------------
// HomePage.html
//----------------------------------------------
// === Whiskful Treats — Fully Enhanced Interactive JS ===
// ---------------------------
// 🌸 CUTE TRANSITION PAGE (HomePage Only)
// ---------------------------
document.addEventListener("DOMContentLoaded", () => {

  // Detect if user is on the home page
  const currentPage = window.location.pathname.toLowerCase();

  if (currentPage.includes("homepage.html") || currentPage.endsWith("/")) {

      // Create transition overlay
      const transition = document.createElement("div");
      transition.id = "transition-screen";
      transition.innerHTML = `
          <div class="transition-content">
              <h1>Sweetheart 💖</h1>
              <p>Still loading your treats...</p>
          </div>
      `;

      Object.assign(transition.style, {
          position: "fixed",
          top: "0",
          left: "0",
          width: "100vw",
          height: "100vh",
          background: "linear-gradient(135deg, #ffe4f0, #ffd6dd)",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          fontFamily: "Arial",
          color: "#ff6b81",
          zIndex: "999999",
          opacity: "1",
          transition: "opacity 1.2s ease"
      });

      document.body.appendChild(transition);

      // Fade out after 2 seconds
      setTimeout(() => {
          transition.style.opacity = "0";
          setTimeout(() => transition.remove(), 1200);
      }, 2000);

      // Floating emojis only on home page
      function floatEmoji() {
          const emoji = document.createElement("div");
          emoji.textContent = ["🍰","🧁","🍪","🍓","🍫"][Math.floor(Math.random()*5)];
          Object.assign(emoji.style, {
              position: "fixed",
              top: "100vh",
              left: `${Math.random()*100}vw`,
              fontSize: "30px",
              opacity: "0.8",
              zIndex: "999999",
              transition: "transform 3s linear, opacity 3s linear"
          });
          transition.appendChild(emoji);
          requestAnimationFrame(() => {
              emoji.style.transform = "translateY(-120vh)";
              emoji.style.opacity = "0";
          });
          setTimeout(() => emoji.remove(), 3000);
      }
      setInterval(floatEmoji, 300);
  }


  // ---------------------------
  // 💗 FREE DELIVERY BANNER (shows on all pages)
  // ---------------------------
  const banner = document.createElement("div");
  banner.innerHTML = 'ORDER today between <b>10am and 12PM</b> to get <b>FREE delivery</b> 🚚💕';

  Object.assign(banner.style, {
      width: "100%",
      padding: "12px 0",
      background: "#ff6b81",
      color: "#fff",
      fontSize: "18px",
      fontWeight: "bold",
      textAlign: "center",
      position: "fixed",
      top: "0",
      left: "0",
      zIndex: "9999",
      boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
      fontFamily: "Arial",
  });

  document.body.appendChild(banner);
  document.body.style.paddingTop = "60px";
});

document.addEventListener('DOMContentLoaded', () => {

  // === Color Palettes ===
  const lightPalette = {
    bodyBg: "linear-gradient(135deg, #fff0f5, #ffe4e1)",
    text: "#444",
    headerBg: "#ffe6eb",
    linkHoverBg: "#ffb6c1",
    heading: "#ff6b81",
    tagline: "#666",
    introText: "#333",
    cardBg: "#fff",
    cardShadow: "0 2px 6px rgba(0,0,0,0.1)",
    buttonBg: "#ff6b81",
    buttonHoverBg: "#ff85a1",
    lightboxBg: "rgba(255,255,255,0.9)",
    lightboxText: "#444",
    accordionBg: "#ffe6eb",
    accordionText: "#444",
    searchBorder: "1px solid #ccc",
    searchPlaceholder: "#999"
  };

  const darkPalette = {
    bodyBg: "#1e1e2f",
    text: "#f0f0f0",
    headerBg: "#2b2b3f",
    linkHoverBg: "#ff8aa1",
    heading: "#ff9bb3",
    tagline: "#ccc",
    introText: "#e0e0e0",
    cardBg: "#2b2b3f",
    cardShadow: "0 2px 8px rgba(0,0,0,0.5)",
    buttonBg: "#ff6b81",
    buttonHoverBg: "#ff85a1",
    lightboxBg: "rgba(30,30,47,0.95)",
    lightboxText: "#f0f0f0",
    accordionBg: "#2b2b3f",
    accordionText: "#f0f0f0",
    searchBorder: "1px solid #555",
    searchPlaceholder: "#ccc"
  };

  let darkMode = localStorage.getItem('darkMode') === 'true';

  // === Apply Palette Function ===
  function applyPalette(palette) {
    document.body.style.background = palette.bodyBg;
    document.body.style.color = palette.text;
    document.body.style.transition = "all 0.5s ease";

    const header = document.querySelector("header");
    if(header) header.style.background = palette.headerBg;

    document.querySelectorAll("nav a").forEach(link => {
      link.style.color = palette.text;
      link.addEventListener("mouseover", () => link.style.background = palette.linkHoverBg);
      link.addEventListener("mouseout", () => link.style.background = "");
    });

    document.querySelectorAll("h1, h2").forEach(h => h.style.color = palette.heading);

    const tagline = document.querySelector(".tagline");
    if(tagline) tagline.style.color = palette.tagline;

    const intro = document.querySelector("p.intro");
    if(intro) intro.style.color = palette.introText;

    document.querySelectorAll('.card').forEach(card => {
      card.style.background = palette.cardBg;
      card.style.boxShadow = palette.cardShadow;
      card.style.color = palette.text;

      // Button hover inside card
      card.querySelectorAll('.button').forEach(btn => {
        btn.style.background = palette.buttonBg;
        btn.addEventListener('mouseover', ()=>btn.style.background=palette.buttonHoverBg);
        btn.addEventListener('mouseout', ()=>btn.style.background=palette.buttonBg);
      });
    });

    // Accordion styling
    document.querySelectorAll('.accordion-toggle').forEach(t => {
      t.style.background = palette.accordionBg;
      t.style.color = palette.accordionText;
    });
    document.querySelectorAll('.accordion-content').forEach(c => {
      c.style.background = palette.accordionBg;
      c.style.color = palette.accordionText;
    });

    // Search bar
    const searchBar = document.querySelector('.search-bar');
    if(searchBar){
      searchBar.style.background = palette.cardBg;
      searchBar.style.color = palette.text;
      searchBar.style.border = palette.searchBorder;
      searchBar.style.transition = "all 0.3s ease";
      searchBar.setAttribute("placeholder", "Search sweet treats... 🍰");
    }

    // Lightbox
    document.querySelectorAll('.lightbox').forEach(lightbox => {
      lightbox.style.background = palette.lightboxBg;
      const closeBtn = lightbox.querySelector('.close');
      if(closeBtn) closeBtn.style.color = palette.lightboxText;
    });
  }

  applyPalette(darkMode?darkPalette:lightPalette);

  // === Dark Mode Toggle ===
  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = darkMode?"🌙 Dark Mode":"☀️ Light Mode";
  Object.assign(toggleBtn.style,{
    position:"fixed", bottom:"20px", right:"20px",
    padding:"10px 16px", borderRadius:"30px", border:"none",
    cursor:"pointer", background:"#ff6b81", color:"#fff",
    fontWeight:"600", boxShadow:"0 4px 10px rgba(0,0,0,0.2)",
    zIndex:"10000", transition:"all 0.3s ease"
  });
  document.body.appendChild(toggleBtn);
  toggleBtn.addEventListener('click', ()=>{
    darkMode = !darkMode;
    localStorage.setItem('darkMode', darkMode);
    applyPalette(darkMode?darkPalette:lightPalette);
    toggleBtn.textContent = darkMode?"🌙 Dark Mode":"☀️ Light Mode";
  });

  // === Floating Sweets ===
  function spawnSweet(){
    const sweet = document.createElement('div');
    sweet.textContent = ['🍰','🧁','🍪','🍫'][Math.floor(Math.random()*4)];
    Object.assign(sweet.style,{
      position:'fixed', left:`${Math.random()*100}vw`, top:'100vh',
      fontSize:`${Math.random()*24 +16}px`, pointerEvents:'none',
      opacity:Math.random(), zIndex:9999, transition:'transform 6s linear, opacity 6s linear'
    });
    document.body.appendChild(sweet);
    requestAnimationFrame(()=>{ sweet.style.transform='translateY(-120vh)'; sweet.style.opacity=0 });
    setTimeout(()=>sweet.remove(),6000);
  }
  setInterval(spawnSweet,1500);

  // === Scroll Progress Bar ===
  const progressBar = document.createElement('div');
  Object.assign(progressBar.style,{
    position:'fixed', top:'0', left:'0', width:'0%', height:'5px',
    background:'#ff6b81', zIndex:10000, transition:'width 0.1s ease'
  });
  document.body.appendChild(progressBar);
  window.addEventListener('scroll', ()=>{
    const scrolled = window.scrollY/(document.body.scrollHeight - window.innerHeight);
    progressBar.style.width = `${scrolled*100}%`;
  });

  // === Accordion ===
  document.querySelectorAll('.accordion-toggle').forEach(toggle=>{
    const content = toggle.nextElementSibling;
    content.style.maxHeight='0'; content.style.overflow='hidden';
    content.style.transition='max-height 0.4s ease, opacity 0.4s ease'; content.style.opacity='0';
    toggle.addEventListener('click', ()=>{
      toggle.classList.toggle('active');
      const isActive = toggle.classList.contains('active');
      if(isActive){ content.style.maxHeight=content.scrollHeight+'px'; content.style.opacity='1'; }
      else{ content.style.maxHeight='0'; content.style.opacity='0'; }
    });
  });

  // === Lightbox ===
  document.querySelectorAll('.card img').forEach(img=>{
    img.style.cursor='zoom-in';
    img.addEventListener('click', ()=>{
      const lightbox=document.createElement('div');
      lightbox.className='lightbox';
      lightbox.innerHTML=`<div class="lightbox-content">
        <span class="close" title="Close">&times;</span>
        <img src="${img.src}" alt="${img.alt}">
      </div>`;
      document.body.appendChild(lightbox);
      document.body.style.overflow='hidden';
      const closeBox=()=>{
        lightbox.classList.add('fade-out');
        setTimeout(()=>{ lightbox.remove(); document.body.style.overflow=''; },300);
      };
      lightbox.querySelector('.close').addEventListener('click', closeBox);
      lightbox.addEventListener('click', e=>{ if(e.target===lightbox) closeBox(); });
      document.addEventListener('keydown',function esc(e){ if(e.key==='Escape'){ closeBox(); document.removeEventListener('keydown',esc); }});
    });
  });

  // === Dynamic Products ===
  const productSection=document.querySelector('.cards');
  const products = [
    {name:'Brownies 🍫', desc:'Rich and fudgy chocolate squares.', img:'brownie.jpg', link:'brownies.html'},
    {name:'Tarts 🥧', desc:'Sweet and fruity pastry delights.', img:'tart.jpg', link:'tarts.html'},
    {name:'Cupcakes 🧁', desc:'Fluffy vanilla topped with love.', img:'cupcake.jpg', link:'cupcakes.html'}
  ];
  function loadProducts(){
    products.forEach((p,i)=>{
      const card=document.createElement('div');
      card.className='card fade-in';
      card.style.animationDelay=`${i*0.1}s`;
      card.innerHTML=`<img src="../Images/POE pics/${p.img}" alt="${p.name}">
        <h3>${p.name}</h3><p>${p.desc}</p><a href="${p.link}" class="button">Order Now 💕</a>`;
      productSection.appendChild(card);

      // === Card Enhancements ===
      // 3D tilt
      card.addEventListener('mousemove',e=>{
        const rect=card.getBoundingClientRect();
        const x=e.clientX-rect.left; const y=e.clientY-rect.top;
        const rotateX=((y-rect.height/2)/(rect.height/2))*10;
        const rotateY=((x-rect.width/2)/(rect.width/2))*10;
        card.style.transform=`rotateX(${-rotateX}deg) rotateY(${rotateY}deg)`;
        card.style.transition='transform 0.1s ease';
      });
      card.addEventListener('mouseleave',()=>{ card.style.transform='rotateX(0deg) rotateY(0deg)'; card.style.transition='transform 0.5s ease'; });

      // Image glow
      const img = card.querySelector('img');
      if(img){
        img.style.transition='transform 0.3s ease, box-shadow 0.3s ease';
        card.addEventListener('mouseenter',()=>{ img.style.transform='scale(1.05)'; img.style.boxShadow='0 0 20px rgba(255,107,129,0.6)'; });
        card.addEventListener('mouseleave',()=>{ img.style.transform='scale(1)'; img.style.boxShadow='0 2px 6px rgba(0,0,0,0.1)'; });
      }

      // Button jiggle + sound
      const btn = card.querySelector('.button');
      if(btn){
        btn.style.transition='transform 0.2s ease';
        btn.addEventListener('mouseenter',()=>{ btn.style.transform='rotate(-5deg)'; setTimeout(()=>btn.style.transform='rotate(5deg)',100); setTimeout(()=>btn.style.transform='rotate(0deg)',200); });
        btn.addEventListener('click',()=>{
          const audio = new Audio('https://freesound.org/data/previews/341/341695_5260870-lq.mp3');
          audio.volume=0.2; audio.play();
        });
      }

      // Floating emojis + confetti on hover
      card.addEventListener('mouseenter',()=>{
        const emojis=['🍰','🧁','🍪','🍫'];
        const spawnEmoji=()=>{ const e=document.createElement('div'); e.textContent=emojis[Math.floor(Math.random()*emojis.length)];
          Object.assign(e.style,{position:'fixed', left:`${card.getBoundingClientRect().left+Math.random()*card.offsetWidth}px`, top:`${card.getBoundingClientRect().top}px`, fontSize:`${Math.random()*24+12}px`, opacity:Math.random()*0.8+0.2, pointerEvents:'none', zIndex:9999, transition:'all 3s linear'});
          document.body.appendChild(e); requestAnimationFrame(()=>{ e.style.top=`${Math.random()*window.innerHeight}px`; e.style.left=`${Math.random()*window.innerWidth}px`; e.style.opacity=0; });
          setTimeout(()=>e.remove(),3000);
        };
        for(let i=0;i<5;i++){ setTimeout(spawnEmoji,i*150); }

        // Confetti
        const colors=['#ff6b81','#ffb6c1','#ffe4e1','#ff85a1','#ffc0cb'];
        for(let i=0;i<20;i++){ const conf=document.createElement('div'); conf.textContent='🎉';
          Object.assign(conf.style,{position:'fixed', left:`${card.getBoundingClientRect().left+Math.random()*card.offsetWidth}px`, top:`${card.getBoundingClientRect().top}px`, fontSize:`${Math.random()*20+10}px`, color:colors[Math.floor(Math.random()*colors.length)], zIndex:9999, pointerEvents:'none', opacity:1, transform:`rotate(${Math.random()*360}deg)`, transition:'all 2s ease-out'});
          document.body.appendChild(conf); requestAnimationFrame(()=>{ conf.style.top=`${Math.random()*window.innerHeight}px`; conf.style.left=`${Math.random()*window.innerWidth}px`; conf.style.opacity=0; });
          setTimeout(()=>conf.remove(),2000);
        }
      });

    });
  }
  loadProducts();

  // === Search Filter ===
  const searchInput=document.createElement('input');
  searchInput.placeholder='Search sweet treats... 🍰';
  searchInput.className='search-bar';
  document.querySelector('.featured')?.prepend(searchInput);
  searchInput.addEventListener('input',()=>{
    const query=searchInput.value.toLowerCase();
    document.querySelectorAll('.card').forEach(card=>{
      const name=card.querySelector('h3').textContent.toLowerCase();
      const match=name.includes(query);
      card.style.display=match?'block':'none';
      card.style.transition='opacity 0.3s ease';
      card.style.opacity=match?'1':'0';
    });
  });

  // === Smooth transitions for elements ===
  document.querySelectorAll('header, nav a, .card, h1, h2, .tagline, p, .accordion-toggle, .accordion-content').forEach(el=>{
    el.style.transition='all 0.5s ease';
  });

});


// ----------------------------------------------
// 1. Heading Typing Animation
// ----------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
  const heading = document.querySelector("h2");
  heading.innerHTML = "";
  typeWriter(heading, "About Us 🍰 – Welcome to Our Sweet World!", 50);
});

function typeWriter(element, text, speed) {
  let i = 0;
  const typing = setInterval(() => {
    element.textContent += text.charAt(i);
    i++;
    if (i === text.length) clearInterval(typing);
  }, speed);
}



// ----------------------------------------------
// 2. Section Card Hover + Color Animation
// ----------------------------------------------
const cards = document.querySelectorAll(".section-card");

cards.forEach((card, index) => {
  card.style.padding = "20px";
  card.style.borderRadius = "12px";
  const colors = ["#fff3f8", "#fce8ff", "#fff9dd", "#e7faff"];
  card.style.backgroundColor = colors[index % colors.length];
  card.style.transition = "0.6s ease";

  card.addEventListener("mouseenter", () => {
    card.style.transform = "scale(1.03)";
    card.style.boxShadow = "0 8px 20px rgba(0,0,0,0.15)";
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "scale(1)";
    card.style.boxShadow = "none";
  });
});



// ----------------------------------------------
// 3. Team Member Hover + Clickable Bios + Image Enlarge
// ----------------------------------------------
const teamMembers = document.querySelectorAll(".team-member img");

// TEAM BIOS (fixed bakery manager!)
const bios = {
  "CEO": "Relebogile Phiri – CEO & Head Baker. Master of flavours & creativity!",
  "Pastry Artist": "Lehlogonolo Phiri – Pastry artist specializing in chocolates & décor.",
  "Manager": "Renelioe Phiri – Bakery Manager ensuring perfect daily operations!",
};

teamMembers.forEach(img => {
  img.style.borderRadius = "50%";
  img.style.width = "150px";
  img.style.height = "150px";
  img.style.objectFit = "cover";
  img.style.transition = "0.4s";
  img.style.cursor = "pointer";

  // hover animation
  img.addEventListener("mouseenter", () => {
    img.style.transform = "rotate(3deg) scale(1.1)";
  });

  img.addEventListener("mouseleave", () => {
    img.style.transform = "rotate(0deg) scale(1)";
  });

  // enlarge & show bio on click
  img.addEventListener("click", () => {
    const role = img.alt;
    const bioText = bios[role] || "Bio unavailable.";

    showPopup(`
      <img src="${img.src}" style="width:180px; height:180px; border-radius:15px; object-fit:cover; margin-bottom:10px;">
      ${bioText}
    `);
  });
});



// ----------------------------------------------
// Popup Function (used by bios & fun facts)
// ----------------------------------------------
function showPopup(html) {
  const popup = document.createElement("div");
  popup.style.position = "fixed";
  popup.style.top = "50%";
  popup.style.left = "50%";
  popup.style.transform = "translate(-50%, -50%)";
  popup.style.background = "white";
  popup.style.padding = "20px";
  popup.style.borderRadius = "12px";
  popup.style.boxShadow = "0 0 25px rgba(0,0,0,0.3)";
  popup.style.zIndex = "99999";
  popup.style.textAlign = "center";
  popup.style.width = "300px";

  popup.innerHTML = `
    <div style="font-size:16px; margin-bottom:12px;">${html}</div>
    <button id="closePopup" style="
      padding: 8px 15px;
      border: none;
      background: #ff77b7;
      border-radius: 8px;
      cursor: pointer;
      color: white;
      font-weight: bold;
    ">Close</button>
  `;

  document.body.appendChild(popup);

  document.getElementById("closePopup").onclick = () => popup.remove();
}



// ----------------------------------------------
// 4. Floating Dessert Emojis
// ----------------------------------------------
const desserts = document.querySelectorAll(".floating-dessert");

desserts.forEach(emoji => {
  emoji.style.position = "fixed";
  emoji.style.fontSize = "30px";
  emoji.style.animation = "floatUp 10s linear infinite";
  emoji.style.animationDelay = `${Math.random() * 5}s`;
});

// Inject animation
const floatStyles = document.createElement("style");
floatStyles.textContent = `
@keyframes floatUp {
  0% { transform: translateY(100vh); opacity: 0; }
  20% { opacity: 1; }
  100% { transform: translateY(-120vh); opacity: 0; }
}
`;
document.head.appendChild(floatStyles);



// ----------------------------------------------
// 5. Scroll Reveal Animation
// ----------------------------------------------
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1";
      entry.target.style.transform = "translateY(0)";
    }
  });
}, { threshold: 0.2 });

cards.forEach(card => {
  card.style.opacity = "0";
  card.style.transform = "translateY(40px)";
  card.style.transition = "0.8s ease-out";
  revealObserver.observe(card);
});



// ----------------------------------------------
// 6. Fun Fact Widget
// ----------------------------------------------
const funFactButton = document.createElement("button");
funFactButton.textContent = "🍪 Fun Fact";
funFactButton.style.position = "fixed";
funFactButton.style.right = "20px";
funFactButton.style.bottom = "80px";
funFactButton.style.padding = "12px 18px";
funFactButton.style.borderRadius = "10px";
funFactButton.style.border = "none";
funFactButton.style.background = "#ffb3d9";
funFactButton.style.cursor = "pointer";
funFactButton.style.boxShadow = "0 4px 10px rgba(0,0,0,0.2)";
funFactButton.style.fontWeight = "bold";

document.body.appendChild(funFactButton);

const funFacts = [
  "Did you know? Cookies were invented to test oven temperature!",
  "Baking was first recorded in ancient Egypt!",
  "The first cake was actually flat and bread-like!",
  "A whisk was first used in the 1600s!"
  
];

funFactButton.addEventListener("click", () => {
  const fact = funFacts[Math.floor(Math.random() * funFacts.length)];
  showPopup(fact);
});



// ----------------------------------------------
// 7. THEME TOGGLE (Dark Mode / Light Mode)
// ----------------------------------------------
const themeBtn = document.createElement("button");
themeBtn.textContent = "🌙";
themeBtn.style.position = "fixed";
themeBtn.style.right = "20px";
themeBtn.style.bottom = "20px";
themeBtn.style.padding = "12px 16px";
themeBtn.style.borderRadius = "50%";
themeBtn.style.border = "none";
themeBtn.style.background = "#222";
themeBtn.style.color = "white";
themeBtn.style.cursor = "pointer";
themeBtn.style.boxShadow = "0 4px 10px rgba(0,0,0,0.3)";
themeBtn.style.fontSize = "18px";

document.body.appendChild(themeBtn);

// Load saved theme
if (localStorage.getItem("theme") === "dark") {
  document.body.classList.add("dark-mode");
  themeBtn.textContent = "☀️";
}

// Toggle theme
themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");

  if (document.body.classList.contains("dark-mode")) {
    themeBtn.textContent = "☀️";
    localStorage.setItem("theme", "dark");
  } else {
    themeBtn.textContent = "🌙";
    localStorage.setItem("theme", "light");
  }
});

// --- DARK MODE: Force all text to black ---
const darkStyle = document.createElement("style");
darkStyle.textContent = `
  /* Whole page */
  .dark-mode {
    background: #f5f5f5 !important;
    color: #111 !important;
  }

  /* Every element */
  .dark-mode * {
    color: #111 !important;
  }

  /* Section cards */
  .dark-mode .section-card {
    background: #e9e9e9 !important;
    border: 1px solid #b5b5b5 !important;
  }

  /* Buttons */
  .dark-mode button {
    background: #dcdcdc !important;
    color: #111 !important;
    border: 1px solid #999 !important;
  }

  /* Popup window */
  .dark-mode div[style*="position: fixed"] {
    background: #ffffff !important;
    color: #111 !important;
  }

  .dark-mode div[style*="position: fixed"] * {
    color: #111 !important;
  }
`;
document.head.appendChild(darkStyle);



// ---------------------------------------------
// Products.html
//----------------------------------------------

// === Whiskful Treats Products Page Enhancements ===
document.addEventListener('DOMContentLoaded', () => {

  // === Color Palettes ===
  const lightPalette = {
    bodyBg: "linear-gradient(135deg, #fff0f5, #ffe4e1)",
    text: "#444",
    headerBg: "#ffe6eb",
    linkBg: "#fff",
    linkHoverBg: "#ffb6c1",
    linkText: "#444",
    heading: "#ff6b81",
    tagline: "#666",
    introText: "#333",
    footerBg: "#ffe6eb",
    footerText: "#444"
  };

  const darkPalette = {
    bodyBg: "#1e1e2f",
    text: "#f0f0f0",
    headerBg: "#2b2b3f",
    linkBg: "#2b2b3f",
    linkHoverBg: "#ff6b81",
    linkText: "#f0f0f0",
    heading: "#ff9bb3",
    tagline: "#ccc",
    introText: "#e0e0e0",
    footerBg: "#2b2b3f",
    footerText: "#f0f0f0"
  };

  let darkMode = localStorage.getItem('darkMode') === 'true';

  function applyPalette(palette) {
    document.body.style.background = palette.bodyBg;
    document.body.style.color = palette.text;
    document.body.style.transition = "all 0.5s ease";

    const header = document.querySelector("header");
    if(header) header.style.background = palette.headerBg;

    const footer = document.querySelector("footer");
    if(footer) {
      footer.style.background = palette.footerBg;
      footer.style.color = palette.footerText;
    }

    const h2 = document.querySelector("main h2");
    if(h2) h2.style.color = palette.heading;

    const tagline = document.querySelector(".tagline");
    if(tagline) tagline.style.color = palette.tagline;

    const intro = document.querySelector(".intro");
    if(intro) intro.style.color = palette.introText;

    document.querySelectorAll(".product-links a").forEach(link => {
      link.style.background = palette.linkBg;
      link.style.color = palette.linkText;
      link.addEventListener("mouseover", ()=>{ 
        link.style.background = palette.linkHoverBg; 
        link.style.color = "#fff"; 
        playPopSound();
      });
      link.addEventListener("mouseout", ()=>{ 
        link.style.background = palette.linkBg; 
        link.style.color = palette.linkText; 
      });
    });
  }

  applyPalette(darkMode ? darkPalette : lightPalette);

  // === Dark/Light Theme Toggle ===
  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = darkMode ? "🌙 Dark Mode" : "☀️ Light Mode";
  Object.assign(toggleBtn.style,{
    position:"fixed", bottom:"20px", right:"20px",
    padding:"10px 16px", borderRadius:"30px", border:"none",
    cursor:"pointer", background:"#ff6b81", color:"#fff",
    fontWeight:"600", boxShadow:"0 4px 10px rgba(0,0,0,0.2)",
    zIndex:"10000", transition:"all 0.3s ease"
  });
  document.body.appendChild(toggleBtn);
  toggleBtn.addEventListener('click', ()=>{
    darkMode = !darkMode;
    localStorage.setItem('darkMode', darkMode);
    applyPalette(darkMode ? darkPalette : lightPalette);
    toggleBtn.textContent = darkMode ? "🌙 Dark Mode" : "☀️ Light Mode";
  });

  // === Hover Animation for Product Links ===
  document.querySelectorAll(".product-links a").forEach(link => {
    link.style.transition = "all 0.3s ease";
    link.addEventListener('mouseenter', () => { link.style.transform = "scale(1.1)"; });
    link.addEventListener('mouseleave', () => { link.style.transform = "scale(1)"; });
  });

  // === Floating Sparkles/Emojis ===
  function spawnFloatingEmoji() {
    const emoji = document.createElement('div');
    emoji.textContent = ['🍰','🧁','🍪','✨'][Math.floor(Math.random()*4)];
    Object.assign(emoji.style,{
      position:'fixed',
      left: Math.random()*100 + 'vw',
      top: '100vh',
      fontSize: Math.random()*24+16+'px',
      opacity: Math.random(),
      pointerEvents:'none',
      zIndex:9999,
      transition:'transform 6s linear, opacity 6s linear'
    });
    document.body.appendChild(emoji);
    requestAnimationFrame(() => { emoji.style.transform = 'translateY(-120vh)'; emoji.style.opacity = 0; });
    setTimeout(()=>emoji.remove(),6000);
  }
  setInterval(spawnFloatingEmoji, 1500);

  // === Confetti on Product Click ===
  function spawnConfetti(x, y) {
    const colors = ['#ff6b81','#ffb6c1','#ffe4e1','#ff85a1','#ffc0cb','#fff'];
    for(let i=0;i<30;i++){
      const conf = document.createElement('div');
      conf.textContent = '🎉';
      Object.assign(conf.style,{
        position:'fixed', left: x + (Math.random()*100-50) + 'px',
        top: y + (Math.random()*100-50) + 'px',
        fontSize: Math.random()*20+10+'px',
        color: colors[Math.floor(Math.random()*colors.length)],
        pointerEvents:'none', zIndex:10000, opacity:1,
        transform:`rotate(${Math.random()*360}deg)`, transition:'all 1.5s ease-out'
      });
      document.body.appendChild(conf);
      requestAnimationFrame(()=>{
        conf.style.top = (parseFloat(conf.style.top)-Math.random()*200)+'px';
        conf.style.left = (parseFloat(conf.style.left)+Math.random()*200-100)+'px';
        conf.style.opacity = 0;
      });
      setTimeout(()=>conf.remove(),1500);
    }
  }
  document.querySelectorAll(".product-links a").forEach(link=>{
    link.addEventListener('click', e=>{
      const rect = link.getBoundingClientRect();
      spawnConfetti(rect.left + rect.width/2, rect.top + rect.height/2);
    });
  });

  // === Scroll-triggered animations ===
  const scrollElems = document.querySelectorAll("main, footer, .product-links");
  function scrollAnimate() {
    scrollElems.forEach(elem => {
      const rect = elem.getBoundingClientRect();
      if(rect.top < window.innerHeight-50) {
        elem.style.opacity = 1;
        elem.style.transform = "translateY(0)";
        elem.style.transition = "all 0.8s ease";
      } else {
        elem.style.opacity = 0;
        elem.style.transform = "translateY(30px)";
      }
    });
  }
  window.addEventListener('scroll', scrollAnimate);
  scrollAnimate();

  // === Scroll progress bar ===
  const progressBar = document.createElement('div');
  Object.assign(progressBar.style,{
    position:'fixed', top:0, left:0, height:'5px', background:'#ff6b81', width:'0%', zIndex:10000
  });
  document.body.appendChild(progressBar);
  window.addEventListener('scroll', () => {
    const scrolled = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
    progressBar.style.width = scrolled + '%';
  });

  // === Surprise Treat Popups ===
  function showSurprise() {
    const popup = document.createElement('div');
    popup.textContent = ["A cupcake just winked at you! 🧁","Yum! A cookie appears! 🍪","Sweet treat incoming! 🍰"][Math.floor(Math.random()*3)];
    Object.assign(popup.style,{
      position:'fixed', bottom: Math.random()*50+'px', right: Math.random()*50+'px',
      padding:'8px 12px', background:'#ffb6c1', color:'#fff', borderRadius:'20px', boxShadow:'0 2px 6px rgba(0,0,0,0.2)',
      zIndex:10000, opacity:0, transition:'opacity 0.5s ease'
    });
    document.body.appendChild(popup);
    requestAnimationFrame(()=>popup.style.opacity = 1);
    setTimeout(()=>popup.remove(),3000);
  }
  setInterval(showSurprise, 15000); // every 15 seconds

  // === Sound effect on hover ===
  const popSound = new Audio('https://freesound.org/data/previews/82/82372_1022651-lq.mp3');
  function playPopSound(){ popSound.currentTime=0; popSound.play(); }

  // === Countdown Timer for Special Offers ===
  const countdown = document.createElement('div');
  countdown.style.cssText = 'position:fixed; top:10px; right:20px; background:#ff6b81; color:#fff; padding:8px 12px; border-radius:20px; z-index:10000; font-weight:600';
  document.body.appendChild(countdown);
  const endDate = new Date();
  endDate.setHours(endDate.getHours()+2); // 2 hours countdown
  function updateCountdown(){
    const now = new Date();
    let diff = Math.max(0, endDate - now);
    const h = Math.floor(diff/1000/60/60);
    const m = Math.floor((diff/1000/60)%60);
    const s = Math.floor((diff/1000)%60);
    countdown.textContent = `⏰ Special Offer Ends in ${h}h ${m}m ${s}s`;
  }
  setInterval(updateCountdown, 1000);
  updateCountdown();

});

// ---------------------------------------------
// Cakes.html
//----------------------------------------------
// === script.js ===

// Data for cakes
const cakes = [
  {
    name: "Classic Vanilla Cake (8-inch)",
    description: "Light, fluffy vanilla sponge with creamy frosting.",
    price: "R250.00",
    image: "../Images/POE pics/vanilla cake.webp",
    alt: "Vanilla cake",
    badge: "⭐ Best Seller",
    type: "cake",
    link: "Enquiry.html"
  },
  {
    name: "Chocolate Fudge Cake (8-inch)",
    description: "Rich, moist chocolate layers with creamy fudge frosting.",
    price: "R280.00",
    image: "../Images/POE pics/Chocolate Fudge cake.webp",
    alt: "Chocolate Fudge Cake",
    badge: "",
    type: "cake",
    link: "Enquiry.html"
  },
  {
    name: "Red Velvet Layer Cake",
    description: "Velvety sponge with a tangy cream cheese frosting.",
    price: "R300.00",
    image: "../Images/POE pics/Red velvet cake.webp",
    alt: "Red Velvet Cake",
    badge: "💖 Popular",
    type: "cake",
    link: "Enquiry.html"
  },
  {
    name: "Banto Birthday Cake 🎉",
    description: "Custom designs for birthdays & celebrations.",
    price: "From R350.00",
    image: "../Images/POE pics/Banto cake.jpeg",
    alt: "Banto Birthday Cake",
    badge: "",
    type: "cake",
    link: "Enquiry.html"
  },
  {
    name: "Chocolate Ice Cream Cake (8-inch)",
    description: "Cool, creamy chocolate delight with layers of ice cream.",
    price: "From R250.00",
    image: "../Images/POE pics/chocolate ice cream.webp",
    alt: "Chocolate Ice Cream Cake",
    badge: "",
    type: "cake",
    link: "Enquiry.html"
  },
  {
    name: "Strawberry Cake (8-inch)",
    description: "Fresh sponge with layers of strawberry cream.",
    price: "From R250.00",
    image: "../Images/POE pics/strawberry cake.webp",
    alt: "Strawberry Cake",
    badge: "",
    type: "cake",
    link: "Enquiry.html"
  }
];

// Display cakes
function displayCakes(cakesArray) {
  const grid = document.querySelector('.product-grid');
  grid.innerHTML = "";

  cakesArray.forEach(cake => {
    const card = document.createElement('div');
    card.classList.add('product-card');

    if (cake.badge) {
      const badge = document.createElement('span');
      badge.classList.add('badge');
      badge.textContent = cake.badge;
      card.appendChild(badge);
    }

    const img = document.createElement('img');
    img.src = cake.image;
    img.alt = cake.alt;
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => enlargeImage(img.src, img.alt));
    card.appendChild(img);

    const info = document.createElement('div');
    info.classList.add('product-info');

    const name = document.createElement('h3');
    name.textContent = cake.name;
    info.appendChild(name);

    const desc = document.createElement('p');
    desc.textContent = cake.description;
    info.appendChild(desc);

    const price = document.createElement('span');
    price.classList.add('price');
    price.textContent = cake.price;
    info.appendChild(price);

    const link = document.createElement('a');
    link.href = cake.link;
    link.classList.add('order-btn');
    link.textContent = cake.badge.includes("Customize") ? "Customize Now" : "Order Now";
    info.appendChild(link);

    card.appendChild(info);
    grid.appendChild(card);
  });
}

function enlargeImage(src, alt) {
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.background = 'rgba(0,0,0,0.75)';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.zIndex = '10000';
  overlay.addEventListener('click', () => document.body.removeChild(overlay));

  const img = document.createElement('img');
  img.src = src;
  img.alt = alt;

  /* 🔥 FIX: Permanent small size */
  img.style.width = '300px';   // fixed width (never gets bigger)
  img.style.height = 'auto';   // keeps proportions
  img.style.maxHeight = '300px'; // prevents tall images from growing
  img.style.objectFit = 'contain';

  img.style.borderRadius = '12px';
  img.style.boxShadow = '0 0 20px rgba(0, 0, 0, 0.5)';

  overlay.appendChild(img);
  document.body.appendChild(overlay);
}


// Setup dropdown filter
function setupDropdown() {
  const dropdown = document.createElement('select');
  const main = document.querySelector('main');
  dropdown.style.margin = '20px 0';
  dropdown.style.padding = '10px';
  dropdown.style.fontSize = '1rem';

  const options = [
    { value: 'all', text: 'All Cakes & Desserts' },
    { value: 'best-seller', text: 'Best Selling Cakes' },
    { value: 'popular', text: 'Popular Cakes' },
  
  ];

  options.forEach(opt => {
    const option = document.createElement('option');
    option.value = opt.value;
    option.textContent = opt.text;
    dropdown.appendChild(option);
  });

  main.insertBefore(dropdown, main.querySelector('.product-grid'));

  dropdown.addEventListener('change', () => {
    const value = dropdown.value;
    let filtered = cakes;

    if (value === 'best-seller') {
      filtered = cakes.filter(cake => cake.badge.includes("Best Seller"));
    } else if (value === 'popular') {
      filtered = cakes.filter(cake => cake.badge.includes("Popular") || cake.badge.includes("💖"));
    } else if (value === 'cookies') {
      // For now empty because cookies are on another page
      filtered = [];
    }

    displayCakes(filtered);
  });
}

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
  displayCakes(cakes);
  setupDropdown();
});

// ---------------------------------------------
// Desserts.html
//----------------------------------------------
// === Light/Dark Mode Toggle ===
const toggleBtn = document.getElementById("themeToggle");

toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");

  toggleBtn.textContent =
    document.body.classList.contains("dark-mode")
      ? "☀️ Light Mode"
      : "🌙 Dark Mode";
});

// === Enlarge Image When Clicked (not too big) ===
document.querySelectorAll(".product-card img").forEach(img => {
  img.addEventListener("click", () => {
    img.style.transform = img.style.transform === "scale(1.6)"
      ? "scale(1)"
      : "scale(1.6)";
  });
});

// ---------------------------------------------
// PartyPacks.html
//----------------------------------------------
const boxesData = [
  {title:"Custom", img:"../Images/POE pics/Custom box.png", desc:"Personalized themes available"},
  {title:"Barbie", img:"../Images/POE pics/Barbie Party Pack.jpeg", desc:"Includes Barbie-themed accessories"},
  {title:"Bluey", img:"../Images/POE pics/Bluey party pack.webp", desc:"Features Bluey characters"},
  {title:"Cocomelon", img:"../Images/POE pics/Cocomelon party pack.jpeg", desc:"Colorful cocomelon theme"},
  {title:"Baby Shark", img:"../Images/POE pics/Baby shark.webp", desc:"Colorful Baby Shark theme"},
  {title:"Spiderman", img:"../Images/POE pics/Spiderman.webp", desc:"Spiderman theme"},
  {title:"Minnie", img:"../Images/POE pics/Mickey Mouse.jpeg", desc:"Minnie Mouse theme"},
  {title:"Marshmallow", img:"../Images/POE pics/Marshmallow Party Favors.jpeg", desc:"Marshmallow"},
  {title:"Safari", img:"../Images/POE pics/Safari.avif", desc:"Safari-themed"},
  {title:"Ben 10", img:"../Images/POE pics/Ben 10.webp", desc:"Ben 10 theme"}
];

const container = document.getElementById("boxesContainer");

// Render boxes dynamically
function renderBoxes(filter="all") {
  container.innerHTML = "";
  boxesData.forEach(box => {
    if(filter !== "all" && box.title !== filter) return;

    const div = document.createElement("div");
    div.className = "box";
    div.innerHTML = `
      <h2>${box.title}</h2>
      <img src="${box.img}" alt="${box.title} Party Box">
      <p>${box.desc}</p>
      <p><strong>Price:</strong> R85,00 – R160,00</p>
      <a href="enquiry.html" class="btn">Enquire Now</a>
    `;
    container.appendChild(div);
  });
  addBoxInteractions();
}

// Add hover, lightbox, and button interactions
function addBoxInteractions() {
  const boxes = document.querySelectorAll(".box");
  boxes.forEach(box => {
    const img = box.querySelector("img");
    const btn = box.querySelector(".btn");

    // Image lightbox
    img.addEventListener("click", () => {
      const modal = document.createElement("div");
      modal.className = "lightbox";
      const modalImg = document.createElement("img");
      modalImg.src = img.src;
      modal.appendChild(modalImg);
      document.body.appendChild(modal);
      modal.addEventListener("click", () => modal.remove());
    });

    // Enquire button popup
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      // Add cute animation or message
      alert("🎉 Your enquiry has been sent! 🎉");
      window.location.href = btn.href;
    });

    // Smooth image enlarge on hover
    img.addEventListener("mouseenter", () => img.style.transform = "scale(1.2) rotate(2deg)");
    img.addEventListener("mouseleave", () => img.style.transform = "scale(1) rotate(0deg)");
  });
}

// Initial render
renderBoxes();

// Filter change
document.getElementById("themeFilter").addEventListener("change", (e) => {
  renderBoxes(e.target.value);
});

// ---------------------------------------------
//Enquiry.html
//----------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');

  // === Get inputs ===
  const inputs = {
    name: document.getElementById('name'),
    email: document.getElementById('email'),
    phone: document.getElementById('phone'),
    branch: document.getElementById('branch'),
    enquiry: document.getElementById('enquiry-type'),
    message: document.getElementById('message')
  };

  // === Create feedback elements ===
  const feedbacks = {};
  const emojis = {};
  for (const key in inputs) {
    const feedback = document.createElement('small');
    feedback.style.display = 'block';
    feedback.style.marginTop = '3px';
    inputs[key].parentNode.insertBefore(feedback, inputs[key].nextSibling);
    feedbacks[key] = feedback;

    // Emoji feedback
    const emoji = document.createElement('span');
    emoji.style.marginLeft = '5px';
    inputs[key].parentNode.insertBefore(emoji, inputs[key].nextSibling);
    emojis[key] = emoji;
  }

  // === Message character counter ===
  const charCounter = document.createElement('small');
  charCounter.style.display = 'block';
  charCounter.style.marginTop = '2px';
  inputs.message.parentNode.appendChild(charCounter);

  // === Validation functions ===
  const validateName = () => {
    if (inputs.name.value.trim() === '') {
      feedbacks.name.textContent = 'Full Name is required';
      feedbacks.name.style.color = 'red';
      inputs.name.style.border = '2px solid red';
      emojis.name.textContent = '';
      return false;
    }
    feedbacks.name.textContent = '';
    inputs.name.style.border = '2px solid green';
    emojis.name.textContent = '✨';
    return true;
  };

// === Live email validation ===
inputs.email.addEventListener('input', () => {
  const val = inputs.email.value;
  if (val === '') {
    feedbacks.email.textContent = 'Enter your email (must contain @)';
    feedbacks.email.style.color = 'gray';
    inputs.email.style.border = '1px solid #ccc';
    emojis.email.textContent = '';
  } else if (!val.includes('@')) {
    feedbacks.email.textContent = 'Email must contain "@"';
    feedbacks.email.style.color = 'red';
    inputs.email.style.border = '2px solid red';
    emojis.email.textContent = '';
  } else {
    feedbacks.email.textContent = 'Looks good!';
    feedbacks.email.style.color = 'green';
    inputs.email.style.border = '2px solid green';
    emojis.email.textContent = '✅';
  }
});

// === Live phone validation ===
inputs.phone.addEventListener('input', () => {
  inputs.phone.value = inputs.phone.value.replace(/\D/g, '');
  if (inputs.phone.value.length > 10) inputs.phone.value = inputs.phone.value.slice(0, 10);
  if (inputs.phone.value.length > 0 && inputs.phone.value[0] !== '0') {
    inputs.phone.value = '0' + inputs.phone.value.slice(1);
  }

  const len = inputs.phone.value.length;
  if (len === 0) {
    feedbacks.phone.textContent = 'Enter a phone number starting with 0 (10 digits)';
    feedbacks.phone.style.color = 'gray';
    inputs.phone.style.border = '1px solid #ccc';
    emojis.phone.textContent = '';
  } else if (len < 10) {
    feedbacks.phone.textContent = 'Phone must have 10 digits';
    feedbacks.phone.style.color = 'orange';
    inputs.phone.style.border = '2px solid orange';
    emojis.phone.textContent = '';
  } else {
    feedbacks.phone.textContent = 'Valid phone ✅';
    feedbacks.phone.style.color = 'green';
    inputs.phone.style.border = '2px solid green';
    emojis.phone.textContent = '📞';
  }
});


  const validateBranch = () => {
    if (inputs.branch.value === '') {
      feedbacks.branch.textContent = 'Please select a branch';
      feedbacks.branch.style.color = 'red';
      inputs.branch.style.border = '2px solid red';
      emojis.branch.textContent = '';
      return false;
    }
    feedbacks.branch.textContent = '';
    inputs.branch.style.border = '2px solid green';
    emojis.branch.textContent = '🏬';
    return true;
  };

  const validateEnquiry = () => {
    if (inputs.enquiry.value === '') {
      feedbacks.enquiry.textContent = 'Please select an enquiry type';
      feedbacks.enquiry.style.color = 'red';
      inputs.enquiry.style.border = '2px solid red';
      emojis.enquiry.textContent = '';
      return false;
    }
    feedbacks.enquiry.textContent = '';
    inputs.enquiry.style.border = '2px solid green';
    emojis.enquiry.textContent = '📩';
    return true;
  };

  const validateMessage = () => {
    const val = inputs.message.value.trim();
    if (val === '') {
      feedbacks.message.textContent = 'Message is required';
      feedbacks.message.style.color = 'red';
      inputs.message.style.border = '2px solid red';
      emojis.message.textContent = '';
      return false;
    }
    feedbacks.message.textContent = '';
    inputs.message.style.border = '2px solid green';
    emojis.message.textContent = '📝';

    // Easter egg: bakery-themed word
    if (val.toLowerCase().includes('cake')) {
      feedbacks.message.textContent = '🎂 You love cake too!';
      feedbacks.message.style.color = '#ff69b4';
    }

    return true;
  };

  // === Live validation events ===
  inputs.name.addEventListener('input', validateName);
  inputs.email.addEventListener('input', validateEmail);
  inputs.branch.addEventListener('change', validateBranch);
  inputs.enquiry.addEventListener('change', validateEnquiry);
  inputs.message.addEventListener('input', () => {
    validateMessage();
    charCounter.textContent = `${inputs.message.value.length}/500 characters`;
    charCounter.style.color = inputs.message.value.length > 500 ? 'red' : 'green';
    if (inputs.message.value.length > 500) {
      inputs.message.value = inputs.message.value.slice(0, 500);
    }
  });

  // === Phone input restrictions ===
  inputs.phone.addEventListener('input', () => {
    inputs.phone.value = inputs.phone.value.replace(/\D/g, '');
    if (inputs.phone.value.length > 10) inputs.phone.value = inputs.phone.value.slice(0, 10);
    if (inputs.phone.value.length > 0 && inputs.phone.value[0] !== '0') {
      inputs.phone.value = '0' + inputs.phone.value.slice(1);
    }
    validatePhone();
  });

  // === Input focus animation ===
  for (const key in inputs) {
    inputs[key].addEventListener('focus', () => {
      inputs[key].style.transition = '0.3s all';
      inputs[key].style.boxShadow = '0 0 10px #ffb6c1';
    });
    inputs[key].addEventListener('blur', () => {
      inputs[key].style.boxShadow = '';
    });
  }

  // === Form submission ===
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const isValid = validateName() & validateEmail() & validatePhone() &
                    validateBranch() & validateEnquiry() & validateMessage();
    if (!isValid) {
      alert('Please correct the errors before submitting!');
      return;
    }

    // === Popup ===
    const popup = document.createElement('div');
    popup.innerHTML = `
      <div style="
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #fff0f5;
        border: 3px solid #ffb6c1;
        padding: 20px 30px;
        text-align: center;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.2);
        font-family: 'Comic Sans MS', cursive, sans-serif;
        z-index: 1000;
      ">
        <h2>🎉 Submission Successful! 🎂</h2>
        <p>Thank you for reaching out! We'll get back to you soon.</p>
        <button id="close-popup" style="
          background-color: #ffb6c1;
          border: none;
          padding: 10px 20px;
          border-radius: 8px;
          cursor: pointer;
          margin-top: 10px;
        ">Close</button>
      </div>
    `;
    document.body.appendChild(popup);

    // === Confetti animation ===
    const confetti = document.createElement('div');
    confetti.style.position = 'fixed';
    confetti.style.top = 0;
    confetti.style.left = 0;
    confetti.style.width = '100%';
    confetti.style.height = '100%';
    confetti.style.pointerEvents = 'none';
    document.body.appendChild(confetti);

    for(let i=0;i<100;i++){
      const dot = document.createElement('div');
      dot.style.position = 'absolute';
      dot.style.width = dot.style.height = '10px';
      dot.style.backgroundColor = ['#ffb6c1','#ffe4e1','#ff69b4','#ffc0cb'][Math.floor(Math.random()*4)];
      dot.style.top = Math.random()*100+'%';
      dot.style.left = Math.random()*100+'%';
      dot.style.borderRadius = '50%';
      dot.style.animation = `fall ${2+Math.random()*3}s linear forwards`;
      confetti.appendChild(dot);
    }

    const style = document.createElement('style');
    style.textContent = `
      @keyframes fall { to { transform: translateY(100vh); opacity: 0; } }
    `;
    document.head.appendChild(style);

    // Auto-remove popup and confetti
    const removePopup = () => {
      popup.remove();
      confetti.remove();
      form.reset();
      for (const key in feedbacks) {
        feedbacks[key].textContent = '';
        inputs[key].style.border = '';
        emojis[key].textContent = '';
      }
      charCounter.textContent = '';
    };

    document.getElementById('close-popup').addEventListener('click', removePopup);
    setTimeout(removePopup, 5000); // auto-close after 5s
  });
});


/// -- Contact.html --->
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');

  // === Get inputs ===
  const inputs = {
    name: document.getElementById('name'),
    email: document.getElementById('email'),
    phone: document.getElementById('phone'),
    branch: document.getElementById('branch'),
    enquiry: document.getElementById('enquiry-type'),
    message: document.getElementById('message')
  };

  // === Create feedback and emoji elements ===
  const feedbacks = {};
  const emojis = {};
  for (const key in inputs) {
    const feedback = document.createElement('small');
    feedback.style.display = 'block';
    feedback.style.marginTop = '3px';
    inputs[key].parentNode.insertBefore(feedback, inputs[key].nextSibling);
    feedbacks[key] = feedback;

    const emoji = document.createElement('span');
    emoji.style.marginLeft = '5px';
    inputs[key].parentNode.insertBefore(emoji, inputs[key].nextSibling);
    emojis[key] = emoji;
  }

  // === Message character counter ===
  const charCounter = document.createElement('small');
  charCounter.style.display = 'block';
  charCounter.style.marginTop = '2px';
  inputs.message.parentNode.appendChild(charCounter);

  // === Validation functions ===
  const validateName = () => {
    if (inputs.name.value.trim() === '') {
      feedbacks.name.textContent = 'Full Name is required';
      feedbacks.name.style.color = 'red';
      inputs.name.style.border = '2px solid red';
      emojis.name.textContent = '';
      return false;
    }
    feedbacks.name.textContent = '';
    inputs.name.style.border = '2px solid green';
    emojis.name.textContent = '✨';
    return true;
  };

  const validateEmail = () => {
    const val = inputs.email.value.trim();
    if (!val.includes('@')) {
      feedbacks.email.textContent = 'Email must contain "@" ❌';
      feedbacks.email.style.color = 'red';
      inputs.email.style.border = '2px solid red';
      emojis.email.textContent = '';
      return false;
    }
    // === Live email validation ===
inputs.email.addEventListener('input', () => {
  const val = inputs.email.value;
  if (val === '') {
    feedbacks.email.textContent = 'Enter your email (must contain @)';
    feedbacks.email.style.color = 'gray';
    inputs.email.style.border = '1px solid #ccc';
    emojis.email.textContent = '';
  } else if (!val.includes('@')) {
    feedbacks.email.textContent = 'Email must contain "@"';
    feedbacks.email.style.color = 'red';
    inputs.email.style.border = '2px solid red';
    emojis.email.textContent = '';
  } else {
    feedbacks.email.textContent = 'Looks good!';
    feedbacks.email.style.color = 'green';
    inputs.email.style.border = '2px solid green';
    emojis.email.textContent = '✅';
  }
});

// === Live phone validation ===
inputs.phone.addEventListener('input', () => {
  inputs.phone.value = inputs.phone.value.replace(/\D/g, '');
  if (inputs.phone.value.length > 10) inputs.phone.value = inputs.phone.value.slice(0, 10);
  if (inputs.phone.value.length > 0 && inputs.phone.value[0] !== '0') {
    inputs.phone.value = '0' + inputs.phone.value.slice(1);
  }

  const len = inputs.phone.value.length;
  if (len === 0) {
    feedbacks.phone.textContent = 'Enter a phone number starting with 0 (10 digits)';
    feedbacks.phone.style.color = 'gray';
    inputs.phone.style.border = '1px solid #ccc';
    emojis.phone.textContent = '';
  } else if (len < 10) {
    feedbacks.phone.textContent = 'Phone must have 10 digits';
    feedbacks.phone.style.color = 'orange';
    inputs.phone.style.border = '2px solid orange';
    emojis.phone.textContent = '';
  } else {
    feedbacks.phone.textContent = 'Valid phone ✅';
    feedbacks.phone.style.color = 'green';
    inputs.phone.style.border = '2px solid green';
    emojis.phone.textContent = '📞';
  }
});

    feedbacks.email.textContent = 'Valid email ✅';
    feedbacks.email.style.color = 'green';
    inputs.email.style.border = '2px solid green';
    emojis.email.textContent = '📧';
    return true;
  };

  const validatePhone = () => {
    const val = inputs.phone.value.trim();
    const regex = /^0\d{9}$/;
    if (!regex.test(val)) {
      feedbacks.phone.textContent = 'Phone must start with 0 and be 10 digits ❌';
      feedbacks.phone.style.color = 'red';
      inputs.phone.style.border = '2px solid red';
      emojis.phone.textContent = '';
      return false;
    }
    feedbacks.phone.textContent = 'Valid phone ✅';
    feedbacks.phone.style.color = 'green';
    inputs.phone.style.border = '2px solid green';
    emojis.phone.textContent = '📞';
    return true;
  };

  const validateBranch = () => {
    if (inputs.branch.value === '') {
      feedbacks.branch.textContent = 'Please select a branch';
      feedbacks.branch.style.color = 'red';
      inputs.branch.style.border = '2px solid red';
      emojis.branch.textContent = '';
      return false;
    }
    feedbacks.branch.textContent = '';
    inputs.branch.style.border = '2px solid green';
    emojis.branch.textContent = '🏬';
    return true;
  };

  const validateEnquiry = () => {
    if (inputs.enquiry.value === '') {
      feedbacks.enquiry.textContent = 'Please select an enquiry type';
      feedbacks.enquiry.style.color = 'red';
      inputs.enquiry.style.border = '2px solid red';
      emojis.enquiry.textContent = '';
      return false;
    }
    feedbacks.enquiry.textContent = '';
    inputs.enquiry.style.border = '2px solid green';
    emojis.enquiry.textContent = '📩';
    return true;
  };

  const validateMessage = () => {
    const val = inputs.message.value.trim();
    if (val === '') {
      feedbacks.message.textContent = 'Message is required';
      feedbacks.message.style.color = 'red';
      inputs.message.style.border = '2px solid red';
      emojis.message.textContent = '';
      return false;
    }
    feedbacks.message.textContent = '';
    inputs.message.style.border = '2px solid green';
    emojis.message.textContent = '📝';

    // Easter egg: if user types "cake"
    if (val.toLowerCase().includes('cake')) {
      feedbacks.message.textContent = '🎂 You love cake too!';
      feedbacks.message.style.color = '#ff69b4';
    }

    // Character counter
    charCounter.textContent = `${val.length}/500 characters`;
    charCounter.style.color = val.length > 500 ? 'red' : 'green';
    if (val.length > 500) inputs.message.value = val.slice(0, 500);

    return true;
  };

  // === Live validation ===
  inputs.name.addEventListener('input', validateName);
  inputs.email.addEventListener('input', validateEmail);
  inputs.phone.addEventListener('input', validatePhone);
  inputs.branch.addEventListener('change', validateBranch);
  inputs.enquiry.addEventListener('change', validateEnquiry);
  inputs.message.addEventListener('input', validateMessage);

  // === Phone input restrictions ===
  inputs.phone.addEventListener('input', () => {
    inputs.phone.value = inputs.phone.value.replace(/\D/g, '');
    if (inputs.phone.value.length > 10) inputs.phone.value = inputs.phone.value.slice(0, 10);
    if (inputs.phone.value.length > 0 && inputs.phone.value[0] !== '0') {
      inputs.phone.value = '0' + inputs.phone.value.slice(1);
    }
    validatePhone();
  });

  // === Input focus glow ===
  for (const key in inputs) {
    inputs[key].addEventListener('focus', () => {
      inputs[key].style.transition = '0.3s all';
      inputs[key].style.boxShadow = '0 0 10px #ffb6c1';
    });
    inputs[key].addEventListener('blur', () => {
      inputs[key].style.boxShadow = '';
    });
  }

  // === Shake animation for errors ===
  const shakeInput = (input) => {
    input.style.animation = 'shake 0.3s';
    setTimeout(() => input.style.animation = '', 300);
  };
  const style = document.createElement('style');
  style.textContent = `
  @keyframes shake {
    0% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    50% { transform: translateX(5px); }
    75% { transform: translateX(-5px); }
    100% { transform: translateX(0); }
  }
  @keyframes fall { to { transform: translateY(100vh); opacity: 0; } }
  `;
  document.head.appendChild(style);

  // === Confetti function ===
  const confettiEffect = () => {
    const confetti = document.createElement('div');
    confetti.style.position = 'fixed';
    confetti.style.top = 0;
    confetti.style.left = 0;
    confetti.style.width = '100%';
    confetti.style.height = '100%';
    confetti.style.pointerEvents = 'none';
    document.body.appendChild(confetti);

    for (let i = 0; i < 50; i++) {
      const dot = document.createElement('div');
      dot.style.position = 'absolute';
      dot.style.width = dot.style.height = '10px';
      dot.style.backgroundColor = ['#ffb6c1','#ffe4e1','#ff69b4','#ffc0cb'][Math.floor(Math.random()*4)];
      dot.style.top = Math.random()*100+'%';
      dot.style.left = Math.random()*100+'%';
      dot.style.borderRadius = '50%';
      dot.style.animation = `fall ${2+Math.random()*2}s linear forwards`;
      confetti.appendChild(dot);
    }
    setTimeout(() => confetti.remove(), 3000);
  };

  // === Form submission ===
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const valid = validateName() & validateEmail() & validatePhone() &
                  validateBranch() & validateEnquiry() & validateMessage();

    if (!valid) {
      alert("Please correct the errors before submitting!");
      if (!validateName()) shakeInput(inputs.name);
      if (!validateEmail()) shakeInput(inputs.email);
      if (!validatePhone()) shakeInput(inputs.phone);
      if (!validateBranch()) shakeInput(inputs.branch);
      if (!validateEnquiry()) shakeInput(inputs.enquiry);
      if (!validateMessage()) shakeInput(inputs.message);
      return;
    }

    // === Success popup ===
    const popup = document.createElement('div');
    popup.innerHTML = `
      <div style="
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #fff0f5;
        border: 3px solid #ffb6c1;
        padding: 20px 30px;
        text-align: center;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.2);
        font-family: 'Comic Sans MS', cursive, sans-serif;
        z-index: 1000;
      ">
        <h2>🎉 Submission Successful! 🎂</h2>
        <p>Thank you for reaching out! We'll get back to you soon.</p>
        <button id="close-popup" style="
          background-color: #ffb6c1;
          border: none;
          padding: 10px 20px;
          border-radius: 8px;
          cursor: pointer;
          margin-top: 10px;
        ">Close</button>
      </div>
    `;
    document.body.appendChild(popup);

    // Confetti
    confettiEffect();

    const removePopup = () => {
      popup.remove();
      form.reset();
      for (const key in feedbacks) {
        feedbacks[key].textContent = '';
        inputs[key].style.border = '';
        emojis[key].textContent = '';
      }
      charCounter.textContent = '';
    };

    document.getElementById('close-popup').addEventListener('click', removePopup);
    setTimeout(removePopup, 5000);
  });
});
