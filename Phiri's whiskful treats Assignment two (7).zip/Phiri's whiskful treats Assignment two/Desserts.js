// ==================== DATA ====================
const desserts = [
  { name: "Mini Cheesecakes 🍰", description: "Rich, creamy, and delicious!", price: "R30 each", image: "../Images/POE pics/mini cheesecakes.webp", alt: "Mini Cheesecakes", badge: "", link: "Enquiry.html" },
  { name: "Chocolate Brownies 🍫", description: "Fudgy & irresistible.", price: "R50 (3 pack)", image: "../Images/POE pics/chocolate brownie.webp", alt: "Chocolate Brownies", badge: "", link: "Enquiry.html" },
  { name: "Milk Tart Slice 🥧", description: "Soft, creamy and cinnamon infused.", price: "R25 each", image: "../Images/POE pics/MilkTart.webp", alt: "Milk Tart Slice", badge: "⭐ Popular", link: "Enquiry.html" },
  { name: "Fruit Tarts 🍓", description: "Fresh fruits on creamy custard.", price: "R35 each", image: "../Images/POE pics/Fruit tart.webp", alt: "Fruit Tarts", badge: "", link: "Enquiry.html" },
  { name: "Custard Slices 🍮", description: "Layers of flaky pastry + creamy custard.", price: "R28 each", image: "../Images/POE pics/Custard slice.webp", alt: "Custard Slices", badge: "⭐ Best Seller", link: "Enquiry.html" },
  { name: "Mango Pie 🥭", description: "Sweet, tropical & refreshing.", price: "R40 each", image: "../Images/POE pics/mango pie.webp", alt: "Mango Pie", badge: "⭐ Popular", link: "Enquiry.html" },
  { name: "Cupcakes 🧁", description: "Perfect for any celebration.", price: "From R48 (Dozen)", image: "../Images/POE pics/cupcakes.webp", alt: "Cupcakes", badge: "", link: "Enquiry.html" },
  { name: "Donuts 🍩", description: "Soft & fluffy with toppings.", price: "From R71 (Dozen)", image: "../Images/POE pics/Donut.webp", alt: "Donuts", badge: "⭐ Popular", link: "Enquiry.html" }
];

// ==================== DISPLAY DESSERTS ====================
function displayDesserts(array) {
  const grid = document.querySelector('.product-grid');
  grid.innerHTML = "";

  array.forEach(item => {
    const card = document.createElement('div');
    card.classList.add('product-card');

    if (item.badge) {
      const badge = document.createElement('span');
      badge.classList.add('badge');
      badge.textContent = item.badge;
      card.appendChild(badge);
    }

    const img = document.createElement('img');
    img.src = item.image;
    img.alt = item.alt;
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => enlargeImage(img.src, img.alt));
    card.appendChild(img);

    const info = document.createElement('div');
    info.classList.add('product-info');

    const name = document.createElement('h3');
    name.textContent = item.name;
    info.appendChild(name);

    const desc = document.createElement('p');
    desc.textContent = item.description;
    info.appendChild(desc);

    const price = document.createElement('span');
    price.classList.add('price');
    price.textContent = item.price;
    info.appendChild(price);

    const link = document.createElement('a');
    link.href = item.link;
    link.classList.add('order-btn');
    link.textContent = "Order Now";
    info.appendChild(link);

    card.appendChild(info);
    grid.appendChild(card);
  });
}

// ==================== IMAGE ENLARGEMENT ====================
function enlargeImage(src, alt) {
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.background = 'rgba(0,0,0,0.75)';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.zIndex = '10000';
  overlay.addEventListener('click', () => document.body.removeChild(overlay));

  const img = document.createElement('img');
  img.src = src;
  img.alt = alt;
  img.style.width = '300px';
  img.style.height = 'auto';
  img.style.objectFit = 'contain';
  img.style.borderRadius = '12px';
  img.style.boxShadow = '0 0 20px rgba(0,0,0,0.5)';

  overlay.appendChild(img);
  document.body.appendChild(overlay);
}

// ==================== FILTER DROPDOWN ====================
function setupDropdown() {
  const dropdown = document.createElement('select');
  const main = document.querySelector('main');
  dropdown.style.margin = '20px 0';
  dropdown.style.padding = '10px';
  dropdown.style.fontSize = '1rem';

  const options = [
    { value: 'all', text: 'All Desserts' },
    { value: 'best-seller', text: 'Best Selling Desserts' },
    { value: 'popular', text: 'Popular Desserts' }
  ];

  options.forEach(opt => {
    const option = document.createElement('option');
    option.value = opt.value;
    option.textContent = opt.text;
    dropdown.appendChild(option);
  });

  main.insertBefore(dropdown, main.querySelector('.product-grid'));

  dropdown.addEventListener('change', () => {
    let filtered = desserts;

    if (dropdown.value === 'best-seller') {
      filtered = desserts.filter(d => d.badge === "⭐ Best Seller");
    } else if (dropdown.value === 'popular') {
      filtered = desserts.filter(d => d.badge === "⭐ Popular");
    }

    displayDesserts(filtered);
  });
}


// ==================== SEARCH BAR ====================
function setupSearch() {
  const input = document.getElementById('searchInput');
  if (!input) return;
  input.addEventListener('input', () => {
    const query = input.value.toLowerCase();
    const filtered = desserts.filter(d =>
      d.name.toLowerCase().includes(query) || d.description.toLowerCase().includes(query)
    );
    displayDesserts(filtered);
  });
}

// ==================== DARK MODE ====================
function setupDarkMode() {
  const button = document.getElementById('themeToggle');
  if (!button) return;
  button.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    button.textContent = document.body.classList.contains('dark-mode') ? "☀️ Light Mode" : "🌙 Dark Mode";
  });
}

// ==================== ENQUIRY FORM ====================
function setupForm() {
  const form = document.querySelector('form');
  if (!form) return;

  const inputs = {
    name: document.getElementById('name'),
    email: document.getElementById('email'),
    phone: document.getElementById('phone'),
    branch: document.getElementById('branch'),
    enquiry: document.getElementById('enquiry-type'),
    message: document.getElementById('message')
  };

  const feedbacks = {};
  const emojis = {};
  for (const key in inputs) {
    const fb = document.createElement('small');
    fb.style.display = 'block';
    fb.style.marginTop = '3px';
    inputs[key].parentNode.insertBefore(fb, inputs[key].nextSibling);
    feedbacks[key] = fb;

    const em = document.createElement('span');
    em.style.marginLeft = '5px';
    inputs[key].parentNode.insertBefore(em, inputs[key].nextSibling);
    emojis[key] = em;
  }

  const charCounter = document.createElement('small');
  charCounter.style.display = 'block';
  charCounter.style.marginTop = '2px';
  inputs.message.parentNode.appendChild(charCounter);

  // --- Validation functions ---
  const validateName = () => { /* same as previous merged form */ 
    if(inputs.name.value.trim()===''){feedbacks.name.textContent='Full Name is required';feedbacks.name.style.color='red';inputs.name.style.border='2px solid red';emojis.name.textContent='';return false;}
    feedbacks.name.textContent='';inputs.name.style.border='2px solid green';emojis.name.textContent='✨';return true;
  };
  const validateEmail = () => { const val=inputs.email.value.trim(); if(!val.includes('@')){feedbacks.email.textContent='Email must contain "@" ❌';feedbacks.email.style.color='red';inputs.email.style.border='2px solid red';emojis.email.textContent='';return false;}feedbacks.email.textContent='Valid email ✅';feedbacks.email.style.color='green';inputs.email.style.border='2px solid green';emojis.email.textContent='📧';return true;};
  const validatePhone = () => { const val=inputs.phone.value.trim(); const regex=/^0\d{9}$/; if(!regex.test(val)){feedbacks.phone.textContent='Phone must start with 0 and be 10 digits ❌';feedbacks.phone.style.color='red';inputs.phone.style.border='2px solid red';emojis.phone.textContent='';return false;}feedbacks.phone.textContent='Valid phone ✅';feedbacks.phone.style.color='green';inputs.phone.style.border='2px solid green';emojis.phone.textContent='📞';return true;};
  const validateBranch = () => { if(inputs.branch.value===''){feedbacks.branch.textContent='Please select a branch';feedbacks.branch.style.color='red';inputs.branch.style.border='2px solid red';emojis.branch.textContent='';return false;}feedbacks.branch.textContent='';inputs.branch.style.border='2px solid green';emojis.branch.textContent='🏬';return true;};
  const validateEnquiry = () => { if(inputs.enquiry.value===''){feedbacks.enquiry.textContent='Please select an enquiry type';feedbacks.enquiry.style.color='red';inputs.enquiry.style.border='2px solid red';emojis.enquiry.textContent='';return false;}feedbacks.enquiry.textContent='';inputs.enquiry.style.border='2px solid green';emojis.enquiry.textContent='📩';return true;};
  const validateMessage = () => { const val=inputs.message.value.trim(); if(val===''){feedbacks.message.textContent='Message is required';feedbacks.message.style.color='red';inputs.message.style.border='2px solid red';emojis.message.textContent='';return false;}feedbacks.message.textContent='';inputs.message.style.border='2px solid green';emojis.message.textContent='📝'; if(val.toLowerCase().includes('cake')){feedbacks.message.textContent='🎂 You love cake too!';feedbacks.message.style.color='#ff69b4';} charCounter.textContent=`${val.length}/500 characters`; charCounter.style.color=val.length>500?'red':'green'; if(val.length>500) inputs.message.value=val.slice(0,500); return true;};

  // --- Live validation ---
  inputs.name.addEventListener('input', validateName);
  inputs.email.addEventListener('input', validateEmail);
  inputs.phone.addEventListener('input', validatePhone);
  inputs.branch.addEventListener('change', validateBranch);
  inputs.enquiry.addEventListener('change', validateEnquiry);
  inputs.message.addEventListener('input', validateMessage);

  // --- Phone restrictions ---
  inputs.phone.addEventListener('input',()=>{inputs.phone.value=inputs.phone.value.replace(/\D/g,'');if(inputs.phone.value.length>10) inputs.phone.value=inputs.phone.value.slice(0,10);if(inputs.phone.value.length>0 && inputs.phone.value[0]!=='0') inputs.phone.value='0'+inputs.phone.value.slice(1);validatePhone();});

  // --- Shake animation ---
  const shakeInput = input=>{input.style.animation='shake 0.3s';setTimeout(()=>input.style.animation='',300);}
  const style = document.createElement('style');
  style.textContent=`@keyframes shake{0%{transform:translateX(0);}25%{transform:translateX(-5px);}50%{transform:translateX(5px);}75%{transform:translateX(-5px);}100%{transform:translateX(0);}}@keyframes fall{to{transform:translateY(100vh);opacity:0;}}`;
  document.head.appendChild(style);

  // --- Input focus glow ---
  for(const key in inputs){inputs[key].addEventListener('focus',()=>{inputs[key].style.transition='0.3s all';inputs[key].style.boxShadow='0 0 10px #ffb6c1';});inputs[key].addEventListener('blur',()=>{inputs[key].style.boxShadow='';});}

  // --- Confetti effect ---
  const confettiEffect=()=>{const c=document.createElement('div');c.style.position='fixed';c.style.top=0;c.style.left=0;c.style.width='100%';c.style.height='100%';c.style.pointerEvents='none';document.body.appendChild(c);for(let i=0;i<50;i++){const d=document.createElement('div');d.style.position='absolute';d.style.width=d.style.height='10px';d.style.backgroundColor=['#ffb6c1','#ffe4e1','#ff69b4','#ffc0cb'][Math.floor(Math.random()*4)];d.style.top=Math.random()*100+'%';d.style.left=Math.random()*100+'%';d.style.borderRadius='50%';d.style.animation=`fall ${2+Math.random()*2}s linear forwards`;c.appendChild(d);}setTimeout(()=>c.remove(),3000);};

  // --- Form submission ---
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const valid=validateName()&validateEmail()&validatePhone()&validateBranch()&validateEnquiry()&validateMessage();
    if(!valid){alert("Please correct the errors before submitting!");if(!validateName())shakeInput(inputs.name);if(!validateEmail())shakeInput(inputs.email);if(!validatePhone())shakeInput(inputs.phone);if(!validateBranch())shakeInput(inputs.branch);if(!validateEnquiry())shakeInput(inputs.enquiry);if(!validateMessage())shakeInput(inputs.message);return;}
    confettiEffect();
    const popup=document.createElement('div');
    popup.innerHTML=`<div style="position: fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff0f5;border:3px solid #ffb6c1;padding:20px 30px;text-align:center;border-radius:15px;box-shadow:0 0 20px rgba(0,0,0,0.2);font-family:'Comic Sans MS', cursive, sans-serif;z-index:1000;"><h2>🎉 Submission Successful! 🎂</h2><p>Thank you for reaching out! We'll get back to you soon.</p><button id="close-popup" style="background-color:#ffb6c1;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;margin-top:10px;">Close</button></div>`;
    document.body.appendChild(popup);
    const removePopup=()=>{popup.remove();form.reset();for(const k in feedbacks){feedbacks[k].textContent='';inputs[k].style.border='';emojis[k].textContent='';}charCounter.textContent='';};
    document.getElementById('close-popup').addEventListener('click',removePopup);
    setTimeout(removePopup,5000);
  });
}

// ==================== INITIALIZE PAGE ====================
document.addEventListener('DOMContentLoaded', () => {
  displayDesserts(desserts);
  setupDropdown();
  setupSearch();
  setupDarkMode();
  setupForm();
});

// =========================
  // 🔍 SEARCH & FILTER FUNCTIONALITY
  // =========================
  function filterProducts() {
    const searchText = searchInput.value.toLowerCase();
    const filterValue = filterSelect.value;

    productCards.forEach(card => {
      const title = card.querySelector("h3").textContent.toLowerCase();
      const desc = card.querySelector("p").textContent.toLowerCase();
      const badge = card.querySelector(".badge")
        ? card.querySelector(".badge").textContent.toLowerCase()
        : "";

      const matchesSearch =
        title.includes(searchText) || desc.includes(searchText);

      let matchesFilter = true;
      if (filterValue === "best") matchesFilter = badge.includes("best seller");
      if (filterValue === "popular") matchesFilter = badge.includes("popular");

      card.style.display =
        matchesSearch && matchesFilter ? "block" : "none";
    });
  }

  searchInput.addEventListener("input", filterProducts);
  filterSelect.addEventListener("change", filterProducts);
