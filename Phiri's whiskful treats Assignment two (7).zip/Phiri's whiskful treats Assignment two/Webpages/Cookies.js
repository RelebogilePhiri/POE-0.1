// =========================
// 🍪 COOKIES PAGE JS
// =========================
document.addEventListener("DOMContentLoaded", () => {

  const body = document.body;
  const searchInput = document.getElementById('searchInput');
  const filterSelect = document.getElementById('filterSelect');
  const productCards = document.querySelectorAll('.product-card');

  // =========================
  // 🌙 LIGHT/DARK MODE TOGGLE
  // =========================
  let darkMode = localStorage.getItem('darkMode') === 'true';

  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = darkMode ? "🌙 Dark Mode" : "☀️ Light Mode";

  Object.assign(toggleBtn.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "10px 16px",
    borderRadius: "30px",
    border: "none",
    cursor: "pointer",
    background: "#ff6b81",
    color: "#fff",
    fontWeight: "600",
    boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
    zIndex: "10000",
    transition: "all 0.3s ease"
  });

  document.body.appendChild(toggleBtn);

  const lightPalette = {
    bodyBg: "#fff",
    text: "#222",
    cardBg: "#fff"
  };

  const darkPalette = {
    bodyBg: "#222",
    text: "#eee",
    cardBg: "#333"
  };

  function applyPalette(palette) {
    document.body.style.background = palette.bodyBg;
    document.body.style.color = palette.text;
    productCards.forEach(card => {
      card.style.background = palette.cardBg;
      card.style.color = palette.text;
    });
  }

  applyPalette(darkMode ? darkPalette : lightPalette);

  toggleBtn.addEventListener("click", () => {
    darkMode = !darkMode;
    localStorage.setItem("darkMode", darkMode);
    applyPalette(darkMode ? darkPalette : lightPalette);
    toggleBtn.textContent = darkMode ? "🌙 Dark Mode" : "☀️ Light Mode";
  });

  // =========================
  // 🔍 SEARCH & FILTER FUNCTIONALITY
  // =========================
  function filterProducts() {
    const searchText = searchInput.value.toLowerCase();
    const filterValue = filterSelect.value;

    productCards.forEach(card => {
      const title = card.querySelector("h3").textContent.toLowerCase();
      const desc = card.querySelector("p").textContent.toLowerCase();
      const badge = card.querySelector(".badge")
        ? card.querySelector(".badge").textContent.toLowerCase()
        : "";

      const matchesSearch =
        title.includes(searchText) || desc.includes(searchText);

      let matchesFilter = true;
      if (filterValue === "best") matchesFilter = badge.includes("best seller");
      if (filterValue === "popular") matchesFilter = badge.includes("popular");

      card.style.display =
        matchesSearch && matchesFilter ? "block" : "none";
    });
  }

  searchInput.addEventListener("input", filterProducts);
  filterSelect.addEventListener("change", filterProducts);

  // =========================
  // 🖼️ IMAGE HOVER EFFECT (NO CLICK ENLARGE)
  // =========================
  productCards.forEach(card => {
    const img = card.querySelector("img");

    img.style.transition = "transform 0.3s ease, box-shadow 0.3s ease";

    img.addEventListener("mouseenter", () => {
      img.style.transform = "scale(1.05)";
      img.style.boxShadow = "0 8px 20px rgba(0,0,0,0.15)";
    });

    img.addEventListener("mouseleave", () => {
      img.style.transform = "scale(1)";
      img.style.boxShadow = "none";
    });
  });

  // =========================
  // 🪟 POPUP MODAL FOR IMAGE CLICK
  // =========================
  // Create modal container
  const modal = document.createElement("div");
  modal.id = "imgModal";
  Object.assign(modal.style, {
    display: "none",
    position: "fixed",
    inset: "0",
    background: "rgba(0,0,0,0.65)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: "20000"
  });

  // Small image inside modal
  const modalImg = document.createElement("img");
  Object.assign(modalImg.style, {
    width: "250px",
    borderRadius: "10px",
    boxShadow: "0 10px 25px rgba(0,0,0,0.3)"
  });

  modal.appendChild(modalImg);
  document.body.appendChild(modal);

  // Open modal on image click
  productCards.forEach(card => {
    const img = card.querySelector("img");

    img.addEventListener("click", () => {
      modalImg.src = img.src;
      modal.style.display = "flex";
    });
  });

  // Close modal when clicking background
  modal.addEventListener("click", () => {
    modal.style.display = "none";
  });

});
